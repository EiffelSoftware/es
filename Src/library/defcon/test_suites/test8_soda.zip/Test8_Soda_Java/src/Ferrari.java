
public interface Ferrari extends Car {

}
