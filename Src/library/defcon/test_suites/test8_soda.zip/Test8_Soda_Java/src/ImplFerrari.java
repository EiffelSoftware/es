
public class ImplFerrari implements Ferrari {
	private String name;
	
	public ImplFerrari() {
		
	}
	
	public ImplFerrari(String n) {
		name = n;
	}
	
	public void print() {
		System.out.println("Ferrari: " + name);
	}
}
