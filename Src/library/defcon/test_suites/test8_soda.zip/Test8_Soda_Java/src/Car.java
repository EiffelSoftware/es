
public interface Car {
	public static final String NAME = "a car";
	
	void print();
}
