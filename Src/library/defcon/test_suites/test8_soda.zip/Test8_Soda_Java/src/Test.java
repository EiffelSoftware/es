import com.db4o.*;
import com.db4o.query.*;

public class Test {

	public static void main(String[] args) {
		Test t = new Test();
		t.test();
	}
	
	private void test() {
		storeCars();
		retrieveCarsBySoda();
	}
	
	private void storeCars() {
		ObjectContainer db = Db4o.openFile("test_soda.yap");
		try {
			Car f1 = new ImplFerrari("F450");
			db.set(f1);
			Car f2 = new ImplFerrari("F430");
			db.set(f2);
			Car b1 = new ImplBmw("Serie 5");
			db.set(b1);
			Car b2 = new ImplBmw("Serie 7");
			db.set(b2);
		} finally {
			db.close();
		}
	}
	
	private void retrieveCarsBySoda() {
		ObjectContainer db = Db4o.openFile("test_soda.yap");
		try {
			System.out.println("----------All cars with name=\"F450\"---------");
			Query q1 = db.query();
			q1.constrain(Car.class);
			q1.descend("name").constrain("F450");
			printout(q1.execute());
			
			System.out.println("----------All Ferraris with name=\"F450\"---------");
			Query q2 = db.query();
			q2.constrain(Ferrari.class);
			q2.descend("name").constrain("F450");
			printout(q2.execute());
			
			System.out.println("----------All Bmws with name=\"F450\"---------");
			Query q3 = db.query();
			q3.constrain(Bmw.class);
			q3.descend("name").constrain("F450");
			printout(q3.execute());
		} finally {
			db.close();
		}
	}
	
	private void printout(ObjectSet os) {
		Object obj;
		Car c;
		while (os.hasNext()) {
			obj = os.next();
			if (obj instanceof Car) {
				c = (Car)obj;
				c.print();
			}			
		}
	}
}
