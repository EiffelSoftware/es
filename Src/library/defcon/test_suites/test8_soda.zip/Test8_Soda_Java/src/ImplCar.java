
public class ImplCar implements Car {
	private String name;
	
	public ImplCar() {		
		
	}
	
	public ImplCar(String n) {
		name = n;
	}
	
	public void print() {
		System.out.println("Car: " + name);
	}
	
}
