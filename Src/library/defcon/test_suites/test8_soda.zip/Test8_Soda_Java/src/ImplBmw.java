
public class ImplBmw implements Bmw {
	private String name;
	
	public ImplBmw() {
		
	}
	
	public ImplBmw(String n) {		
		name = n;
	}
	
	public void print() {
		System.out.println("Bmw: " + name);
	}
}
