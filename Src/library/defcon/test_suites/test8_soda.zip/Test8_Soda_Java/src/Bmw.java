
public interface Bmw extends Car {

}
