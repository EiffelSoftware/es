using System;
using System.Collections.Generic;
using System.Text;
using RootCluster;
using EiffelSoftware.Library.Base.Kernel;
using System.Reflection;
using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using System.IO;
using Db4objects.Db4o.Query;

namespace TestNet
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.test();
        }

        private void test()
        {
            File.Delete("testnet.yap");
            storeCars();
            retrieveInterfaceCarsBySoda();
            //retrieveClassCarsBySoda();
        }

        private void storeCars()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                Ferrari f1 = RootCluster.Create.Ferrari.Make("F450");
                db.Set(f1);
                Ferrari f2 = RootCluster.Create.Ferrari.Make("F430");
                db.Set(f2);
                Bmw b1 = RootCluster.Create.Bmw.Make("Serie 5");
                db.Set(b1);
                Bmw b2 = RootCluster.Create.Bmw.Make("Serie 7");
                db.Set(b2);
            }
            finally
            {
                db.Close();
            }
        }

        private void retrieveInterfaceCarsBySoda()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                Console.WriteLine("---------All cars with $$systemname=\"F450\"-------------------");
                IQuery query1 = db.Query();
                query1.Constrain(typeof(Car));
                query1.Descend("$$systemname").Constrain("F450");
                print(query1.Execute());

                Console.WriteLine("---------All Ferraris with $$systemname=\"F450\"-------------------");
                IQuery query2 = db.Query();
                query2.Constrain(typeof(Ferrari));
                query2.Descend("$$systemname").Constrain("F450");
                print(query2.Execute());

                Console.WriteLine("---------All Bmws with $$systemname=\"F450\"-------------------");
                IQuery query3 = db.Query();
                query3.Constrain(typeof(Bmw));
                query3.Descend("$$systemname").Constrain("F450");
                print(query3.Execute());
            }
            finally
            {
                db.Close();
            }
        }

        private void retrieveClassCarsBySoda()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                Console.WriteLine("---------All cars with $$systemname=\"F450\"-------------------");
                IQuery query1 = db.Query();
                query1.Constrain(typeof(RootCluster.Impl.Car));
                query1.Descend("$$systemname").Constrain("F450");
                print(query1.Execute());

                Console.WriteLine("---------All Ferraris with $$systemname=\"F450\"-------------------");
                IQuery query2 = db.Query();
                query2.Constrain(typeof(RootCluster.Impl.Ferrari));
                query2.Descend("$$systemname").Constrain("F450");
                print(query2.Execute());

                Console.WriteLine("---------All Bmws with $$systemname=\"F450\"-------------------");
                IQuery query3 = db.Query();
                query3.Constrain(typeof(RootCluster.Impl.Bmw));
                query3.Descend("$$systemname").Constrain("F450");
                print(query3.Execute());
            }
            finally
            {
                db.Close();
            }
        }

        private void print(IObjectSet os)
        {
            Car c;
            foreach (object o in os)
            {
                c = o as Car;
                if (c != null)
                {
                    c.PrintOut();
                }
            }
        }
    }
}







 



