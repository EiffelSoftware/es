using System;
using System.Collections.Generic;
using System.Text;
using RootCluster;
using RootCluster.Create;
using RootCluster.Impl;
using EiffelSoftware.Library.Base.Kernel;
using System.Reflection;
using Db4objects.Db4o;

namespace TestNet
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.testExpandedClass();
            p.testExpandedField();            
        }

        private void testExpandedClass()
        {
            storePoint();
            queryPoint();            
        }

        private void storePoint()
        {
            // store an instance of Point
            RootCluster.Point pnt = RootCluster.Create.Point.Make(2, 3);
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                db.Set(pnt);
            }
            finally
            {
                db.Close();
            }

            // get meta data using reflection mechanism
            //reflect(pnt);
            reflect(typeof(Any));
            reflect(typeof(RootCluster.Point));
            reflect(typeof(RootCluster.ReferencePoint));
            reflect(typeof(RootCluster.Impl.ReferencePoint));
            reflect(typeof(RootCluster.Create.Point));
            reflect(typeof(RootCluster.Create.ReferencePoint));
        }

        private void queryPoint()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                RootCluster.Point pnt = RootCluster.Create.Point.DefaultCreate();
                IObjectSet os = db.Get(pnt);
                
                // Reflect fields and properties of the first retrieved instance of Point
                if (os.HasNext())
                {
                    object obj = os.Next();
                    reflectFields(obj);
                    reflectProperties(obj);
                }
            }
            finally
            {
                db.Close();
            }

        }

        private void testExpandedField()
        {
            storeFigure();
            queryFigure();
        }

        private void storeFigure()
        {
            // Store an instance of Point
            RootCluster.Point pnt = RootCluster.Create.Point.Make(3, 5);
            RootCluster.ValueRectangle rect = RootCluster.Create.ValueRectangle.Make(pnt, 7, 9);
            RootCluster.Figure fig = RootCluster.Create.Figure.Make(rect);
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                db.Set(fig);
            }
            finally
            {
                db.Close();
            }

            // get meta data using reflection mechanism
            //reflect(rect);
            reflect(typeof(RootCluster.Rectangle));
            reflect(typeof(RootCluster.ValueRectangle));
            reflect(typeof(RootCluster.Impl.Rectangle));
            reflect(typeof(RootCluster.Create.Rectangle));
            reflect(typeof(RootCluster.Create.ValueRectangle));

            //reflect(fig);
            reflect(typeof(RootCluster.Figure));
            reflect(typeof(RootCluster.Impl.Figure));
            reflect(typeof(RootCluster.Create.Figure));
        }

        private void queryFigure()
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                RootCluster.Figure dfig = RootCluster.Create.Figure.DefaultCreate();
                IObjectSet os = db.Get(dfig);

                // Reflect fields and properties of the first retrieved instance of Figure
                if (os.HasNext())
                {
                    object obj = os.Next();
                    RootCluster.Figure fig = obj as RootCluster.Figure;
                    if (fig != null)
                    {                        
                        Console.WriteLine(fig.ToString());
                    }
                    reflectFields(obj);
                    reflectProperties(obj);
                }
            }
            finally
            {
                db.Close();
            }
        }

        private void reflect(object o)
        {
            Type tp;
            if (o is Type) {
                tp = o as Type;
            } else {
                tp = o.GetType();
            }
            Console.WriteLine("Type: " + tp);
            Console.WriteLine("Name: " + tp.Name);
            Console.WriteLine("Base type: " + tp.BaseType);
            Console.WriteLine("IsClass: " + tp.IsClass);
            Console.WriteLine("IsInterface: " + tp.IsInterface);
            Console.WriteLine("IsAbstract: " + tp.IsAbstract);
            Console.WriteLine("IsEnum: " + tp.IsEnum);
            Console.WriteLine("IsValueType: " + tp.IsValueType);
            Console.WriteLine("ReflectedType: " + tp.ReflectedType);
            Console.WriteLine("UnderlyingSystemType: " + tp.UnderlyingSystemType);
            Console.Write("Interfaces: ");
            Type[] interfaces = tp.GetInterfaces();
            foreach (Type t in interfaces)
            {
                Console.Write(t.Name + ", ");
            }
            Console.WriteLine();
            reflectFields(o);
            reflectProperties(o);
            Console.WriteLine();
        }

        private void reflectFields(object o)
        {
            Type tp;
            if (o is Type)
            {
                tp = o as Type;
            }
            else
            {
                tp = o.GetType();
            }
            Console.WriteLine("Fields in " + tp.Name + ":");
            FieldInfo[] fields = tp.GetFields();
            foreach (FieldInfo f in fields)
            {
                Console.WriteLine(f.Name + " (FieldType: " + f.FieldType + ")");
            }
            Console.WriteLine();
        }

        private void reflectProperties(object o)
        {
            Type tp;
            if (o is Type)
            {
                tp = o as Type;
            }
            else
            {
                tp = o.GetType();
            }
            Console.WriteLine("Properties in " + tp.Name + ":");
            PropertyInfo[] properties = tp.GetProperties();
            foreach (PropertyInfo p in properties)
            {
                Console.WriteLine("Property name: " + p.Name + ", type: " + p.GetType() + ", CanRead: " + p.CanRead + ", CanWrite: " + p.CanWrite + ", property type: " + p.PropertyType);
            }
            Console.WriteLine();
        } 
    }
}

