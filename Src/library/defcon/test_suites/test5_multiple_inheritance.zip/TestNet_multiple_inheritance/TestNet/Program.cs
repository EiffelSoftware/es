using System;
using System.Collections.Generic;
using System.Text;
using RootCluster;
using EiffelSoftware.Library.Base.Kernel;
using System.Reflection;
using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using System.IO;

namespace TestNet
{
    class Program
    {
        TextWriter tw;

        static void Main(string[] args)
        {
            Program p = new Program();
            //p.reflectMetadata();
            p.test();
            //p.testFeatures();
        }

        private void testFeatures()
        {
            // rename
            Polygon p = RootCluster.Create.Polygon.MakeWithVertices(makeVertices(3));
            //RootCluster.Impl.Polygon p = (RootCluster.Impl.Polygon)RootCluster.Create.Polygon.MakeWithVertices(makeVertices(3));
            p._set_Stroke(makeVertices(4));   // method available in RootCluster.Polygon, but not available in RootCluster.Impl.Polygon
            p._set_Vertices(makeVertices(5));
            MethodInfo m = typeof(RootCluster.Impl.Polygon).GetMethod("_set_Stroke", BindingFlags.FlattenHierarchy | BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);

            // same problem with renaming:
            Parallelogram par = RootCluster.Create.Parallelogram.MakeWith_4Vertices(makeVertices(4));
            //RootCluster.Impl.Parallelogram par = (RootCluster.Impl.Parallelogram)RootCluster.Create.Parallelogram.MakeWith_4Vertices(makeVertices(4));
            par.MakeWithVertices(makeVertices(4));
            par.MakeWith_4Vertices(makeVertices(4));

            // select
            Square sq = RootCluster.Create.Square.MakeWith_4Vertices(makeVertices(4));
            int height1 = sq.Height1(); // 50
            int height2 = sq.Height2(); // 20
            int width = sq.Width(); // 0
            int height = sq.Height();   // 0         
        }

        private void reflectMetadata()
        {
            tw = new StreamWriter("metadata.txt");

            reflect(typeof(EiffelSoftware.Runtime.EIFFEL_TYPE_INFO));
            reflect(typeof(Any));

            reflect(typeof(RootCluster.Figure));
            reflect(typeof(RootCluster.Impl.Figure));

            reflect(typeof(RootCluster.Polygon));
            reflect(typeof(RootCluster.Impl.Polygon));
            reflect(typeof(RootCluster.Create.Polygon));

            reflect(typeof(RootCluster.Symmetry));
            reflect(typeof(RootCluster.Impl.Symmetry));

            reflect(typeof(RootCluster.Parallelogram));
            reflect(typeof(RootCluster.Impl.Parallelogram));
            reflect(typeof(RootCluster.Create.Parallelogram));

            reflect(typeof(RootCluster.Rectangle));
            reflect(typeof(RootCluster.Impl.Rectangle));
            reflect(typeof(RootCluster.Create.Rectangle));

            reflect(typeof(RootCluster.Rhombus));
            reflect(typeof(RootCluster.Impl.Rhombus));
            reflect(typeof(RootCluster.Create.Rhombus));

            reflect(typeof(RootCluster.Square));
            reflect(typeof(RootCluster.Impl.Square));
            reflect(typeof(RootCluster.Create.Square));

            reflect(typeof(RootCluster.Point));
            reflect(typeof(RootCluster.ReferencePoint));
            reflect(typeof(RootCluster.Impl.ReferencePoint));
            reflect(typeof(RootCluster.Create.Point));
            reflect(typeof(RootCluster.Create.ReferencePoint));

            reflect(typeof(RootCluster.Point_3d));
            reflect(typeof(RootCluster.ReferencePoint_3d));
            reflect(typeof(RootCluster.Impl.ReferencePoint_3d));
            reflect(typeof(RootCluster.Create.Point_3d));
            reflect(typeof(RootCluster.Create.ReferencePoint_3d));
                        
            tw.Close();
        }

        private void test()
        {
            Square sq = RootCluster.Create.Square.MakeWith_4Vertices(makeVertices(4));
            store(sq);
            Square defaultSq = RootCluster.Create.Square.DefaultCreate();
            Array arrSq = retrieve(defaultSq);  // returns all the direct instances of RootCluster.Impl.Square

            Rectangle rec = RootCluster.Create.Rectangle.MakeWith_4Vertices(makeVertices(4));
            store(rec);
            Rectangle defaultRec = RootCluster.Create.Rectangle.DefaultCreate();
            Array arrRec = retrieve(defaultRec); // returns all the direct instances of RootCluster.Impl.Rectangle

            Rhombus rh = RootCluster.Create.Rhombus.MakeWith_4Vertices(makeVertices(4));
            store(rh);
            Rhombus defaultRh = RootCluster.Create.Rhombus.DefaultCreate();
            Array arrRh = retrieve(defaultRh);  // returns all the direct instances of RootCluster.Impl.Rhombus

            Parallelogram par = RootCluster.Create.Parallelogram.MakeWith_4Vertices(makeVertices(4));
            store(par);
            Parallelogram defaultPar = RootCluster.Create.Parallelogram.DefaultCreate();
            Array arrPar = retrieve(defaultPar); // returns all the direct instances of RootCluster.Impl.Parallelogram

            Polygon pol = RootCluster.Create.Polygon.MakeWithVertices(makeVertices(7));
            store(pol);
            Polygon defaultPol = RootCluster.Create.Polygon.DefaultCreate();
            Array arrPol = retrieve(defaultPol); // returns all the direct instances of RootCluster.Impl.Polygon
            
            Point p2d = RootCluster.Create.Point.MakeWithXY(57, 68);
            store(p2d);
            Point defaultP2d = RootCluster.Create.Point.DefaultCreate();
            Array arrP2d = retrieve(defaultP2d); // returns all the direct instances of RootCluster.Point

            Point_3d p3d = RootCluster.Create.Point_3d.MakeWithXYZ(57, 68, 67);
            store(p3d);
            Point_3d defaultP3d = RootCluster.Create.Point_3d.DefaultCreate();
            Array arrP3d = retrieve(defaultP3d); // returns all the direct instances of RootCluster.Point_3d

            Array arrRootSq = retrieve(typeof(RootCluster.Square)); // 1. returns all the direct instances of RootCluster.Impl.Square
            Array arrRootRec = retrieve(typeof(RootCluster.Rectangle)); // 2. returns all the direct instances of RootCluster.Impl.Square, RootCluster.Impl.Rectangle
            Array arrRootRh = retrieve(typeof(RootCluster.Rhombus));  // 3. returns all the direct instances of RootCluster.Impl.Square, RootCluster.Impl.Rhombus
            Array arrRootPar = retrieve(typeof(RootCluster.Parallelogram));  // 4. returns all the direct instances of RootCluster.Impl.Square, RootCluster.Impl.Rhombus, RootCluster.Impl.Rectangle, RootCluster.Impl.Parallelogram
            Array arrRootPol = retrieve(typeof(RootCluster.Polygon)); // 5. returns RootCluster.Impl.Polygon + results of 4.
            Array arrRootFig = retrieve(typeof(RootCluster.Figure));  // = result of 5.
            Array arrRootSym = retrieve(typeof(RootCluster.Symmetry)); // = result of 4. 
            Array arrRootP2d = retrieve(typeof(RootCluster.Point));  // returns all the direct instances of RootCluster.Point
            Array arrRootP3d = retrieve(typeof(RootCluster.Point_3d));  // returns all the direct instances of RootCluster.Point_3d            
        }

        private void store(object obj)
        {               
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                db.Set(obj);
            }
            finally
            {
                db.Close();
            }
        }

        private Array retrieve(object defaultObj)
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {                
                IObjectSet os = db.Get(defaultObj);
                Array arr = Array.CreateInstance(defaultObj.GetType(), os.Count);
                os.CopyTo(arr, 0);
                return arr;
            }
            finally
            {
                db.Close();
            }
        }

        private Array retrieve(Type tp)
        {
            IObjectContainer db = Db4oFactory.OpenFile("testnet.yap");
            try
            {
                IObjectSet os = db.Get(tp);
                Array arr = Array.CreateInstance(tp, os.Count);
                os.CopyTo(arr, 0);
                return arr;
            }
            finally
            {
                db.Close();
            }
        }

        private ArrayPoint makeVertices(int count)
        {
            ArrayPoint arr = EiffelSoftware.Library.Base.Kernel.Create.ArrayPoint.Make(0, count - 1, null);
            Point p;
            Random rand = new Random();
            for (int i = 0; i < count; i++)
            {
                p = RootCluster.Create.Point.MakeWithXY(rand.Next(1, 100), rand.Next(1, 100));
                ((ToSpecialPoint)arr).Put(p, i);
            }
            return arr;
        }

        private void reflect(object o)
        {
            Type tp;
            if (o is Type) {
                tp = o as Type;
            } else {
                tp = o.GetType();
            }
 
            tw.WriteLine("Type: " + tp);
            tw.WriteLine("Name: " + tp.Name);
            tw.WriteLine("Base type: " + tp.BaseType);
            tw.WriteLine("IsClass: " + tp.IsClass);
            tw.WriteLine("IsInterface: " + tp.IsInterface);
            tw.WriteLine("IsAbstract: " + tp.IsAbstract);
            tw.WriteLine("IsEnum: " + tp.IsEnum);
            tw.WriteLine("IsValueType: " + tp.IsValueType);
            tw.WriteLine("ReflectedType: " + tp.ReflectedType);
            tw.WriteLine("UnderlyingSystemType: " + tp.UnderlyingSystemType);
            tw.Write("Interfaces: ");
            Type[] interfaces = tp.GetInterfaces();
            foreach (Type t in interfaces)
            {
                tw.Write(t.Name + ", ");
            }
            tw.WriteLine();
            tw.WriteLine("Constructors: ");
            ConstructorInfo[] constructors = tp.GetConstructors(BindingFlags.FlattenHierarchy | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static);
            foreach (ConstructorInfo c in constructors)
            {
                tw.WriteLine("\t" + c.Attributes + " " + c + ", ");
            }
            tw.WriteLine();
            tw.WriteLine("Methods: ");
            MethodInfo[] methods = tp.GetMethods(BindingFlags.FlattenHierarchy | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static);
            foreach (MethodInfo m in methods) {
                tw.WriteLine("\t" + m.Attributes + " " + m + ", ");
            }
            tw.WriteLine();
            tw.WriteLine("Fields: ");
            FieldInfo[] fields = tp.GetFields(BindingFlags.FlattenHierarchy | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static);
            foreach (FieldInfo f in fields)
            {
                tw.Write("\t" + f.Attributes + " " + f + ", ");
            }
            tw.WriteLine();
            tw.WriteLine("Properties: ");
            PropertyInfo[] properties = tp.GetProperties(BindingFlags.FlattenHierarchy | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static);
            foreach (PropertyInfo p in properties)
            {
                tw.Write("\t" + p.Attributes + " " + p + ", ");
            }
            tw.WriteLine();
        } 
    }
}







 



