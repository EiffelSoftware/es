using System;
using System.Collections.Generic;
using System.Text;

namespace TestNet
{
    class PolygonSubclass : RootCluster.Impl.Polygon
    {
        PolygonSubclass()
        {
            
        }
    }
}
