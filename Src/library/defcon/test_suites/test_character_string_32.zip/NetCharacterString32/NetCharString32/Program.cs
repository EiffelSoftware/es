using System;
using System.Collections.Generic;
using System.Text;
using RootCluster;
using EiffelSoftware.Library.Base.Kernel;
using Db4objects.Db4o;
using System.IO;


namespace NetCharString32
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.test();
        }

        private void test()
        {
            storeCharacter32();
            TestCharacter_32 retrievedCharacter_32 = retrieveCharacter32();
            storeString32();
            TestString_32 retrievedString_32 = retrieveString32();
        }

        // store one instance of RootCluster.TestCharacter_32 in the file "test_character_32_net.yap".
        private void storeCharacter32()
        {
            IObjectContainer db = Db4oFactory.OpenFile("test_character_32_net.yap");
            try
            {
                RootCluster.TestCharacter_32 c32 = RootCluster.Create.TestCharacter_32.Make();
                db.Set(c32);
            }
            finally
            {
                db.Close();
            }
        }

        // Return one instance of RootCluster.TestCharacter_32 stored in the file "test_character_32_net.yap".
        private RootCluster.TestCharacter_32 retrieveCharacter32()
        {
            IObjectContainer db = Db4oFactory.OpenFile("test_character_32_net.yap"); ;
            try
            {
                RootCluster.TestCharacter_32 defaultc32 = RootCluster.Create.TestCharacter_32.DefaultCreate();
                IObjectSet os = db.Get(defaultc32);
                RootCluster.TestCharacter_32 resc32 = null;
                if (os.HasNext())
                {
                    resc32 = os.Next() as RootCluster.TestCharacter_32;
                }
                return resc32;
            }
            finally
            {
                db.Close();
            }
        }

        // store one instance of RootCluster.TestString_32 in the file "test_string_32_net.yap".
        private void storeString32()
        {
            IObjectContainer db = Db4oFactory.OpenFile("test_string_32_net.yap");
            try
            {
                RootCluster.TestString_32 s32 = RootCluster.Create.TestString_32.Make();
                db.Set(s32);
            }
            finally
            {
                db.Close();
            }
        }

        // Return one instance of RootCluster.TestString_32 stored in the file "test_string_32_net.yap".
        private RootCluster.TestString_32 retrieveString32()
        {
            IObjectContainer db = Db4oFactory.OpenFile("test_string_32_net.yap");
            try
            {
                RootCluster.TestString_32 defaults32 = RootCluster.Create.TestString_32.DefaultCreate();
                IObjectSet os = db.Get(defaults32);
                RootCluster.TestString_32 ress32 = null;
                if (os.HasNext())
                {
                    ress32 = os.Next() as RootCluster.TestString_32;
                }
                return ress32;
            }
            finally
            {
                db.Close();
            }
        }
    }
}
